© KAYOKG. Todos os direitos reservados.

## Licença

O conteúdo deste projeto é licenciado sob a licença Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0). Para ver uma cópia desta licença, visite https://creativecommons.org/licenses/by-nc-sa/4.0/.

### Resumo

Você tem permissão para:

- Compartilhar — copiar e redistribuir o material em qualquer meio ou formato
- Adaptar — remixar, transformar e construir sobre o material

Sob as seguintes condições:

- Atribuição — Você deve dar o crédito apropriado, fornecer um link para a licença e indicar se foram feitas alterações. Você pode fazê-lo de qualquer maneira razoável, mas não de maneira que sugira que o licenciante o endossa ou aprova o seu uso.
- NãoComercial — Você não pode usar o material para fins comerciais.
- CompartilhaIgual — Se você remixar, transformar ou construir sobre o material, deve distribuir suas contribuições sob a mesma licença que o original.

### Aviso Legal

Esta é uma licença humanamente legível resumo do texto legal completo da CC BY-NC-SA 4.0 disponível em: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode

© KAYOKG. Todos os direitos reservados.

### Atribuição

Você deve dar crédito apropriado, fornecer um link para a licença e indicar se foram feitas alterações. Você pode fazê-lo de qualquer forma razoável, mas não de uma forma que sugira que o licenciante o apoia ou aprova o seu uso.

### Uso Não-Comercial

Você não pode utilizar o código deste projeto para fins comerciais.

### Compartilhamento sob a Mesma Licença

Se você adaptar o código deste projeto, você deve distribuir o seu trabalho sob a mesma licença ou uma compatível.

### Limites de Responsabilidade

Este código é fornecido "tal como está", sem garantias de qualquer tipo, expressas ou implícitas, incluindo, mas não se limitando a, garantias de adequação a um determinado fim e não violação. Em nenhum caso o licenciante será responsável por quaisquer danos diretos, indiretos, incidentais, especiais, exemplares ou consequenciais (incluindo, mas não se limitando a, aquisição de bens ou serviços substitutos, perda de uso, dados ou lucros ou interrupção de negócios) no entanto causados e sob qualquer teoria de responsabilidade, seja em contrato, responsabilidade estrita ou delito (incluindo negligência ou outro) decorrentes de qualquer forma do uso deste código, mesmo que avisado da possibilidade de tais danos.

### Informações de Contato

Para obter mais informações sobre a licença ou o código, entre em contato com KAYOKG através do seguinte endereço de e-mail: kayo.kg@hotmail.com.
